package online.foundfave.foundfaveapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoundfaveapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoundfaveapiApplication.class, args);
	}

}
