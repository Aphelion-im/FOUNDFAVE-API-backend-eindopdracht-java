package online.foundfave.foundfaveapi.enums;

public enum Gender {
    Male,
    Female,
    X
}
